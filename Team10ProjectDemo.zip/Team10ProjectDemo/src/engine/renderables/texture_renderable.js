/*
 * File: texture_renderable.js
 */
import TextureRenderable from "./texture_renderable_pixel_collision.js";
export default TextureRenderable;